<?php
session_start();
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <title>Invitees Check</title>
  </head>
  <body>
    <div class="container mt-5">
        <form class="form-inline" method="post">
            <div class="form-group mx-sm-3 mb-2">
                <label for="inputPassword2" class="sr-only">Password</label>
                <input type="password" class="form-control" name="mname" id="inputPassword2" placeholder="Password">
              </div>
            
            <button type="submit" class="btn btn-primary mb-2" name="sub">Check Details</button>
          </form>
    </div>    
    <?php
        if(isset($_POST['sub']))
        {
            try 
            {
                $server="localhost";
                $user="naeem";
                $pass="Navjivan";
                $db="mbh";
                $conn=new mysqli($server,$user,$pass,$db);
                if($conn->connect_error)
                {
                    die("ERROR! while connecting to $db".$conn->connect_error);
                }    
                else
                {
                    // echo "Connection successfull";
                    $passw=$_POST['mname'];
                    $q="SELECT * FROM users WHERE pass=$passw";
                    $result=$conn->query($q);
                    print_r($result);
                    if($result->num_rows>0)
                    {   if($passw===($result->fetch_assoc())['pass'])
                        {
                            $_SESSION['pass']=$passw;
                            header("Location:new.php");
                        }
                        else
                        {
                                echo "something";
                        }
                        // echo "<table border=1 cellspacing=0 cellpadding=10>";
                        // echo "<tr><th>Name</th><th>number</th><th>Email</th></tr>";
                        // while($rows=$result->fetch_assoc())
                        // {
                        //     echo "<tr>";
                        //     echo "<td>".$rows['name']."</td><td>".$rows['mobile']."</td><td>".$rows['email']."</td>";
                        //     echo "</tr>";
                        // }
                        
                        // echo "</table>";
                    }
                    else
                    {
                        header("Location:scanned.html");
                    }
                }
            }
            catch (Exception $th) 
            {
                echo $th->getMessage();
            }
        }
        ?>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>
